
barplot(table(mydata$V1), main="Bar Plot of Attribute 1", xlab = "Results", ylab = "Total Rows" )
barplot(table(mydata$V2), main="Bar Plot of Attribute 2", xlab = "Results", ylab = "Total Rows" )
barplot(table(mydata$V35),main="Bar Plot of Attribute 35", xlab = "Results", ylab = "Total Rows" )

