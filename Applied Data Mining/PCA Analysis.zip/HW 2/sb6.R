pairs(mydata.pca$x[,1:2])


