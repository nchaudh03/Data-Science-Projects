plot(mydata$V22, mydata$V20 
     ,main = "ScatterPlot V22 vs V20, Class V35", xlab = "V22", ylab = "V20"
     ,col = as.factor(mydata$V35))  
legend(x = "topright", legend = levels(as.factor(mydata$V35)), col = c("black", "red"), pch = 1)


plot(mydata$V1, mydata$V2 
     ,main = "ScatterPlot V1 vs V2, Class V35", xlab = "V1", ylab = "V2"
     ,col = as.factor(mydata$V35))  
legend(x = "topright", legend = levels(as.factor(mydata$V35)), col = c("black", "red"), pch = 1)



