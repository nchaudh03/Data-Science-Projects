kl <- kmeans(mydata[,-35],centers=2,nstart=50, algorithm = "Lloyd")
kf <- kmeans(mydata[,-35],centers=2,nstart=50, algorithm = "Forgy")
kh <- kmeans(mydata[,-35],centers=2,nstart=50, algorithm = "Hartigan-Wong")


kl['tot.withinss']
kf['tot.withinss']
kh['tot.withinss']


