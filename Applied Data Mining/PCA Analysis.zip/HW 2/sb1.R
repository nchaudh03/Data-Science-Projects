nrow(mydata)




