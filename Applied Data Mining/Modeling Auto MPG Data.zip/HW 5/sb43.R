
lmm <- lm(mpg ~ 
            cylinders 
          + displacement 
          + horsepower 
          + weight 
          + acceleration 
          + origin 
          + modelyear , data= df)
summary(lmm)
plot(lmm)
