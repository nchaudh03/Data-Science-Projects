res <- performanceEstimation(
  PredTask(mpg ~ ., dfclean[,1:8], "mpg"),
  c(Workflow(learner="lm",pre="knnImp",post="onlyPos"),
    workflowVariants(learner="rpartXse",learner.pars=list(se=c(0,0.5,1)))),
  EstimationTask(metrics="mse",method=CV(nReps=3,nFolds=5)) 
)

summary(res)
plot(res)