disgraph <- filter(df,!is.na(mpg)) %>% mutate(weight=cut(weight, quantile(weight,c(0,0.25,.5,.75,1)), include.lowest=TRUE)) 
ggplot(disgraph,aes(x=mpg,y=origin, color=origin)) + geom_point() +  facet_wrap(~ weight) + guides(color=FALSE) 

