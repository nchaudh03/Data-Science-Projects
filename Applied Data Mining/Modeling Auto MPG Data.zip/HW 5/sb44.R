anova(lmm)
lmm2 <- update(lmm, .~. -acceleration)
summary(lmm2)