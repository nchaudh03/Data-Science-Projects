
dg <- data.frame(lm=final.lm.predict,
                 rt=final.tree.predict,
                 mpg=df[["mpg"]])
ggplot(dg,aes(x=lm,y=mpg)) +
  geom_point() + geom_abline(slope=1,intercept=0,color="red") +
  ggtitle("Linear Model")

ggplot(dg,aes(x=rt,y=mpg)) +
  geom_point() + geom_abline(slope=1,intercept=0,color="red") +
  ggtitle("Linear Model")
