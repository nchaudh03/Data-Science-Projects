final.tree <- rpart(mpg ~ 
                      cylinders 
                    + displacement 
                    + horsepower 
                    + weight 
                    + acceleration 
                    + origin 
                    + modelyear , data= df)
rpart.plot::rpart.plot(final.tree)