(nmse.lm <- mean((final.lm.predict-df[['mpg']])^2)/  #Normalized MSE (NMSE)
  mean((mean(df[['mpg']])-df[['mpg']])^2))

(nmse.rt <- mean((final.tree.predict-df[['mpg']])^2)/  #Normalized MSE (NMSE)
    mean((mean(df[['mpg']])-df[['mpg']])^2))
