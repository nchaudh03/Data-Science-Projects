scatterplot(df$mpg, df$weight)
scatterplot(lms$fitted.values, df$weight)
