final.lm.predict <- predict(final.lm,df)  
final.tree.predict <- predict(final.tree,df) 
mae.mpg.lm <- mean(abs(final.lm.predict - df[["mpg"]])) #2.147
mae.mpg.rt <- mean(abs(final.tree.predict - df[["mpg"]])) #2.229