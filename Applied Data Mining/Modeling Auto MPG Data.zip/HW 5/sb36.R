dfcor <- df[-manyNAs(df, nORp = 0.1), ]
lm(horsepower ~ displacement, data = dfcor)    #40.31 & 0.33
fillhp <- function(hp) ifelse(is.na(hp),NA,40.31 + 0.33 * hp)
df[is.na(df$horsepower), "horsepower"] <- sapply(df[is.na(df$horsepower), "displacement"], fillhp)