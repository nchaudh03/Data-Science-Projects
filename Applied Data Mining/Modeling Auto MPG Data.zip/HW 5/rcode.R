
#Problem 2
rm(list = ls()) 
setwd("C:/Users/Naimesh/Downloads/Applied Data Mining/HW 5")

library(ggplot2) 
library(car) 
library(dplyr)
library(DMwR)
library(rpart)
library(performanceEstimation)
df <- read.table("https://archive.ics.uci.edu/ml/machine-learning-databases/auto-mpg/auto-mpg.data-original") 
columns <- c('mpg','cylinders','displacement','horsepower','weight','acceleration','modelyear','origin','car name') 
colnames(df) <- columns 
summary(df) 
hist(df$displacement) 
qqnorm(df$displacement) #Not straight, seems to be skewed 



boxplot(df$weight) 

df$origin <- as.factor(df$origin)
df$cylinders <- as.factor(df$cylinders)
df$modelyear <- as.factor(df$modelyear)
boxplot(df$mpg, df$origin)
ggplot(df, aes(x = origin, y= mpg)) + geom_boxplot()
ggplot(df, aes(x=origin, y=mpg)) + geom_violin()


disgraph <- filter(df,!is.na(mpg)) %>% mutate(weight=cut(weight, quantile(weight,c(0,0.25,.5,.75,1)), include.lowest=TRUE)) 
ggplot(disgraph,aes(x=mpg,y=origin, color=origin)) + geom_point() +  facet_wrap(~ weight) + guides(color=FALSE) 


#Problem 3
nrow(df)   #406
table(is.na(df))   #14
rw <- manyNAs(df, nORp = 0.1)
dfclean <- centralImputation(df)

symnum(cor(df[,c(1,3,4,5,6)],use="complete.obs"))

dfcor <- df[-manyNAs(df, nORp = 0.1), ]
lm(horsepower ~ displacement, data = dfcor)    #40.31 & 0.33
fillhp <- function(hp) ifelse(is.na(hp),NA,40.31 + 0.33 * hp)
df[is.na(df$horsepower), "horsepower"] <- sapply(df[is.na(df$horsepower), "displacement"], fillhp)

df<- knnImputation(df, k = 5, meth = "median")


#Problem #4
df <- df[,-9]
lms <- lm(mpg ~ weight, data = df)
summary(lms)

scatterplot(df$mpg, df$weight)
scatterplot(lms$fitted.values, df$weight)



lmm <- lm(mpg ~ 
              cylinders 
              + displacement 
              + horsepower 
              + weight 
              + acceleration 
              + origin 
              + modelyear , data= df)
summary(lmm)
plot(lmm)



anova(lmm)
lmm2 <- update(lmm, .~. -acceleration)
summary(lmm2)


final.lm <- step(lmm)

final.tree <- rpart(mpg ~ 
              cylinders 
             + displacement 
             + horsepower 
             + weight 
             + acceleration 
             + origin 
             + modelyear , data= df)
rpart.plot::rpart.plot(final.tree)


#Problem #5


final.lm.predict <- predict(final.lm,df)  
final.tree.predict <- predict(final.tree,df) 


mae.mpg.lm <- mean(abs(final.lm.predict - df[["mpg"]])) #2.147
mae.mpg.rt <- mean(abs(final.tree.predict - df[["mpg"]])) #2.229

mse.mpg.lm <- mean((final.lm.predict - df[["mpg"]])^2) #8.140
mse.mpg.rt <- mean((final.tree.predict - df[["mpg"]])^2) #9.055

dg <- data.frame(lm=final.lm.predict,
                 rt=final.tree.predict,
                 mpg=df[["mpg"]])

ggplot(dg,aes(x=lm,y=mpg)) +
  geom_point() + geom_abline(slope=1,intercept=0,color="red") +
  ggtitle("Linear Model")

ggplot(dg,aes(x=rt,y=mpg)) +
  geom_point() + geom_abline(slope=1,intercept=0,color="red") +
  ggtitle("Linear Model")



#predictive task to compare: one linear model against 3 regression trees
# knnImp to replace missing values
#onlyPos : to make negative predictions to 0. Since we know, thar is not possivle

res <- performanceEstimation(
  PredTask(mpg ~ ., dfclean[,1:8], "mpg"),
  c(Workflow(learner="lm",pre="knnImp",post="onlyPos"),
    workflowVariants(learner="rpartXse",learner.pars=list(se=c(0,0.5,1)))),
  EstimationTask(metrics="mse",method=CV(nReps=3,nFolds=5)) 
)

summary(res)
plot(res)
