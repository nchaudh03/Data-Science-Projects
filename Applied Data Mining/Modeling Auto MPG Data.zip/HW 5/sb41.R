df <- df[,-9]
lms <- lm(mpg ~ weight, data = df)
summary(lms)