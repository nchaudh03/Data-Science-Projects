df <- read.table("https://archive.ics.uci.edu/ml/machine-learning-databases/auto-mpg/auto-mpg.data-original") 
columns <- c('mpg','cylinders','displacement','horsepower','weight','acceleration','modelyear','origin','car name') 
colnames(df) <- columns 
summary(df) 
hist(df$displacement) 
qqnorm(df$displacement) #Not straight, seems to be skewed 